﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sanford.Multimedia.Midi;

namespace MidiPractice
{
    /// <summary>
    /// Main 메서드가 들어있는, 프로그램의 시작점입니다.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // 출력 디바이스 설정 (재생 시 필요)
            OutputDevice outDevice = new OutputDevice(0);

            // 음표들을 담을 악보 생성
            Score score = new Score();

            // 악보에 음표 추가
            score.AddNote(new Note(48, 4, 0, 0));   // 4분음표 C3
            score.AddNote(new Note(52, 4, 0, 4));   // 4분음표 E3
            score.AddNote(new Note(55, 4, 0, 8));   // 4분음표 G3
            score.AddNote(new Note(58, 4, 0, 12));  // 4분음표 Bb3
            score.AddNote(48, 16, 1, 0);            // 온음표 C3
            score.AddNote(52, 16, 1, 0);            // 온음표 E3  (화음)
            score.AddNote(55, 16, 1, 0);            // 온음표 G3  (화음)
            score.AddNote(58, 16, 1, 0);            // 온음표 Bb3 (화음)
            score.AddNote(60, 16, 1, 0);            // 온음표 C4  (화음)
            score.AddNote(48, 16, 2, 0, 9);         // 타악기
            score.AddNote(52, 16, 2, 0, 9);         // 타악기 (화음)
            score.AddNote(55, 16, 2, 0, 9);         // 타악기 (화음)
            score.AddNote(58, 16, 2, 0, 9);         // 타악기 (화음)
            score.AddNote(60, 16, 2, 0, 9);         // 타악기 (화음)

            // 악보를 "Sample.mid" 파일로 저장
            score.Save();

            // 악보 재생
            score.Play(outDevice);
            
            // 출력 디바이스 종료
            // (프로그램이 끝날 때 반드시 적어주세요!)
            outDevice.Close();
        }
    }
}
